//
// Copyright (C) 2005 Michael Tuexen
// Copyright (C) 2008 Irene Ruengeler
// Copyright (C) 2009 Thomas Dreibholz
// Copyright (C) 2009 Thomas Reschka
//               2011 Zoltan Bojthe
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with this program; if not, see <http://www.gnu.org/licenses/>.
//

#include "inet/common/packet/TCPDump.h"

#ifdef WITH_IPv4
#include "inet/networklayer/ipv4/IPv4Datagram.h"
#endif // ifdef WITH_IPv4

namespace inet {

//----

Define_Module(TCPDump);

TCPDump::~TCPDump()
{
}

void TCPDump::initialize()
{
    const char *file = this->par("dumpFile");

    dumpBadFrames = par("dumpBadFrames").boolValue();
    dropBadFrames = par("dropBadFrames").boolValue();

    snaplen = this->par("snaplen");
    tcpdump.setVerbose(par("verbose").boolValue());
    tcpdump.setOutStream(EVSTREAM);

    if (*file)
        pcapDump.openPcap(file, snaplen);
}

void TCPDump::handleMessage(cMessage *msg)
{
    if (msg->isPacket()) {
        bool l2r = msg->arrivedOn("hlIn");
        tcpdump.dumpPacket(l2r, PK(msg));
    }

#ifdef WITH_IPv4
    if (pcapDump.isOpen() && dynamic_cast<IPv4Datagram *>(msg)
        && (dumpBadFrames || !PK(msg)->hasBitError()))
    {
        const simtime_t stime = simTime();
        IPv4Datagram *ipPacket = check_and_cast<IPv4Datagram *>(msg);
        pcapDump.writeFrame(stime, ipPacket);
    }
#endif // ifdef WITH_IPv4

    if (PK(msg)->hasBitError() && dropBadFrames) {
        delete msg;
        return;
    }

    // forward
    int32 index = msg->getArrivalGate()->getIndex();
    int32 id;

    if (msg->getArrivalGate()->isName("ifIn"))
        id = findGate("hlOut", index);
    else
        id = findGate("ifOut", index);

    send(msg, id);
}

void TCPDump::finish()
{
    tcpdump.dump("", "tcpdump finished");
    pcapDump.closePcap();
}

} // namespace inet

